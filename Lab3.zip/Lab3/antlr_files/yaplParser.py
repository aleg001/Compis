# Generated from yapl.g4 by ANTLR 4.13.0
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,45,188,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,1,0,1,0,1,0,4,
        0,14,8,0,11,0,12,0,15,1,0,1,0,1,1,1,1,1,1,1,1,3,1,24,8,1,1,1,1,1,
        1,1,1,1,5,1,30,8,1,10,1,12,1,33,9,1,1,1,1,1,1,2,1,2,1,2,1,2,1,2,
        5,2,42,8,2,10,2,12,2,45,9,2,5,2,47,8,2,10,2,12,2,50,9,2,1,2,1,2,
        1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,3,2,62,8,2,3,2,64,8,2,1,3,1,3,1,
        3,1,3,1,4,1,4,1,4,1,4,1,4,1,4,5,4,76,8,4,10,4,12,4,79,9,4,5,4,81,
        8,4,10,4,12,4,84,9,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,
        1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,4,4,105,8,4,11,4,12,4,106,1,4,1,
        4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,
        4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,3,4,134,8,4,1,4,1,4,1,4,1,4,3,4,140,
        8,4,5,4,142,8,4,10,4,12,4,145,9,4,1,4,1,4,1,4,3,4,150,8,4,1,4,1,
        4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,3,4,164,8,4,1,4,1,4,1,
        4,1,4,1,4,1,4,5,4,172,8,4,10,4,12,4,175,9,4,5,4,177,8,4,10,4,12,
        4,180,9,4,1,4,5,4,183,8,4,10,4,12,4,186,9,4,1,4,0,1,8,5,0,2,4,6,
        8,0,4,2,0,23,23,39,39,1,0,11,12,1,0,13,14,1,0,15,17,216,0,13,1,0,
        0,0,2,19,1,0,0,0,4,63,1,0,0,0,6,65,1,0,0,0,8,149,1,0,0,0,10,11,3,
        2,1,0,11,12,5,1,0,0,12,14,1,0,0,0,13,10,1,0,0,0,14,15,1,0,0,0,15,
        13,1,0,0,0,15,16,1,0,0,0,16,17,1,0,0,0,17,18,5,0,0,1,18,1,1,0,0,
        0,19,20,5,21,0,0,20,23,5,42,0,0,21,22,5,27,0,0,22,24,5,42,0,0,23,
        21,1,0,0,0,23,24,1,0,0,0,24,25,1,0,0,0,25,31,5,2,0,0,26,27,3,4,2,
        0,27,28,5,1,0,0,28,30,1,0,0,0,29,26,1,0,0,0,30,33,1,0,0,0,31,29,
        1,0,0,0,31,32,1,0,0,0,32,34,1,0,0,0,33,31,1,0,0,0,34,35,5,3,0,0,
        35,3,1,0,0,0,36,37,5,43,0,0,37,48,5,4,0,0,38,43,3,6,3,0,39,40,5,
        5,0,0,40,42,3,6,3,0,41,39,1,0,0,0,42,45,1,0,0,0,43,41,1,0,0,0,43,
        44,1,0,0,0,44,47,1,0,0,0,45,43,1,0,0,0,46,38,1,0,0,0,47,50,1,0,0,
        0,48,46,1,0,0,0,48,49,1,0,0,0,49,51,1,0,0,0,50,48,1,0,0,0,51,52,
        5,6,0,0,52,53,5,7,0,0,53,54,5,42,0,0,54,55,5,2,0,0,55,56,3,8,4,0,
        56,57,5,3,0,0,57,64,1,0,0,0,58,61,3,6,3,0,59,60,5,44,0,0,60,62,3,
        8,4,0,61,59,1,0,0,0,61,62,1,0,0,0,62,64,1,0,0,0,63,36,1,0,0,0,63,
        58,1,0,0,0,64,5,1,0,0,0,65,66,5,43,0,0,66,67,5,7,0,0,67,68,5,42,
        0,0,68,7,1,0,0,0,69,70,6,4,-1,0,70,71,5,43,0,0,71,82,5,4,0,0,72,
        77,3,8,4,0,73,74,5,5,0,0,74,76,3,8,4,0,75,73,1,0,0,0,76,79,1,0,0,
        0,77,75,1,0,0,0,77,78,1,0,0,0,78,81,1,0,0,0,79,77,1,0,0,0,80,72,
        1,0,0,0,81,84,1,0,0,0,82,80,1,0,0,0,82,83,1,0,0,0,83,85,1,0,0,0,
        84,82,1,0,0,0,85,150,5,6,0,0,86,87,5,25,0,0,87,88,3,8,4,0,88,89,
        5,32,0,0,89,90,3,8,4,0,90,91,5,22,0,0,91,92,3,8,4,0,92,93,5,24,0,
        0,93,150,1,0,0,0,94,95,5,33,0,0,95,96,3,8,4,0,96,97,5,30,0,0,97,
        98,3,8,4,0,98,99,5,31,0,0,99,150,1,0,0,0,100,104,5,2,0,0,101,102,
        3,8,4,0,102,103,5,1,0,0,103,105,1,0,0,0,104,101,1,0,0,0,105,106,
        1,0,0,0,106,104,1,0,0,0,106,107,1,0,0,0,107,108,1,0,0,0,108,109,
        5,3,0,0,109,150,1,0,0,0,110,111,5,36,0,0,111,150,5,42,0,0,112,113,
        5,10,0,0,113,150,3,8,4,13,114,115,5,28,0,0,115,150,3,8,4,12,116,
        117,5,38,0,0,117,150,3,8,4,8,118,119,5,4,0,0,119,120,3,8,4,0,120,
        121,5,6,0,0,121,150,1,0,0,0,122,150,5,43,0,0,123,150,5,41,0,0,124,
        150,5,40,0,0,125,150,7,0,0,0,126,127,5,43,0,0,127,128,5,44,0,0,128,
        150,3,8,4,2,129,130,5,29,0,0,130,133,3,6,3,0,131,132,5,44,0,0,132,
        134,3,8,4,0,133,131,1,0,0,0,133,134,1,0,0,0,134,143,1,0,0,0,135,
        136,5,5,0,0,136,139,3,6,3,0,137,138,5,44,0,0,138,140,3,8,4,0,139,
        137,1,0,0,0,139,140,1,0,0,0,140,142,1,0,0,0,141,135,1,0,0,0,142,
        145,1,0,0,0,143,141,1,0,0,0,143,144,1,0,0,0,144,146,1,0,0,0,145,
        143,1,0,0,0,146,147,5,26,0,0,147,148,3,8,4,1,148,150,1,0,0,0,149,
        69,1,0,0,0,149,86,1,0,0,0,149,94,1,0,0,0,149,100,1,0,0,0,149,110,
        1,0,0,0,149,112,1,0,0,0,149,114,1,0,0,0,149,116,1,0,0,0,149,118,
        1,0,0,0,149,122,1,0,0,0,149,123,1,0,0,0,149,124,1,0,0,0,149,125,
        1,0,0,0,149,126,1,0,0,0,149,129,1,0,0,0,150,184,1,0,0,0,151,152,
        10,11,0,0,152,153,7,1,0,0,153,183,3,8,4,12,154,155,10,10,0,0,155,
        156,7,2,0,0,156,183,3,8,4,11,157,158,10,9,0,0,158,159,7,3,0,0,159,
        183,3,8,4,10,160,163,10,19,0,0,161,162,5,8,0,0,162,164,5,42,0,0,
        163,161,1,0,0,0,163,164,1,0,0,0,164,165,1,0,0,0,165,166,5,9,0,0,
        166,167,5,43,0,0,167,178,5,4,0,0,168,173,3,8,4,0,169,170,5,5,0,0,
        170,172,3,8,4,0,171,169,1,0,0,0,172,175,1,0,0,0,173,171,1,0,0,0,
        173,174,1,0,0,0,174,177,1,0,0,0,175,173,1,0,0,0,176,168,1,0,0,0,
        177,180,1,0,0,0,178,176,1,0,0,0,178,179,1,0,0,0,179,181,1,0,0,0,
        180,178,1,0,0,0,181,183,5,6,0,0,182,151,1,0,0,0,182,154,1,0,0,0,
        182,157,1,0,0,0,182,160,1,0,0,0,183,186,1,0,0,0,184,182,1,0,0,0,
        184,185,1,0,0,0,185,9,1,0,0,0,186,184,1,0,0,0,19,15,23,31,43,48,
        61,63,77,82,106,133,139,143,149,163,173,178,182,184
    ]

class yaplParser ( Parser ):

    grammarFileName = "yapl.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "';'", "'{'", "'}'", "'('", "','", "')'", 
                     "':'", "'@'", "'.'", "'~'", "'*'", "'/'", "'+'", "'-'", 
                     "'<='", "'<'", "'='", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "'<-'", "'=>'" ]

    symbolicNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "WHITESPACE", "BLOCK_COMMENT", 
                      "LINE_COMMENT", "CLASS", "ELSE", "FALSE", "FI", "IF", 
                      "IN", "INHERITS", "ISVOID", "LET", "LOOP", "POOL", 
                      "THEN", "WHILE", "CASE", "ESAC", "NEW", "OF", "NOT", 
                      "TRUE", "STRING", "INT", "TYPE", "ID", "ASSIGNMENT", 
                      "IMPLY" ]

    RULE_program = 0
    RULE_classdef = 1
    RULE_feature = 2
    RULE_formal = 3
    RULE_expr = 4

    ruleNames =  [ "program", "classdef", "feature", "formal", "expr" ]

    EOF = Token.EOF
    T__0=1
    T__1=2
    T__2=3
    T__3=4
    T__4=5
    T__5=6
    T__6=7
    T__7=8
    T__8=9
    T__9=10
    T__10=11
    T__11=12
    T__12=13
    T__13=14
    T__14=15
    T__15=16
    T__16=17
    WHITESPACE=18
    BLOCK_COMMENT=19
    LINE_COMMENT=20
    CLASS=21
    ELSE=22
    FALSE=23
    FI=24
    IF=25
    IN=26
    INHERITS=27
    ISVOID=28
    LET=29
    LOOP=30
    POOL=31
    THEN=32
    WHILE=33
    CASE=34
    ESAC=35
    NEW=36
    OF=37
    NOT=38
    TRUE=39
    STRING=40
    INT=41
    TYPE=42
    ID=43
    ASSIGNMENT=44
    IMPLY=45

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.0")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class ProgramContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return yaplParser.RULE_program

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class ProgramasContext(ProgramContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a yaplParser.ProgramContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def EOF(self):
            return self.getToken(yaplParser.EOF, 0)
        def classdef(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(yaplParser.ClassdefContext)
            else:
                return self.getTypedRuleContext(yaplParser.ClassdefContext,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterProgramas" ):
                listener.enterProgramas(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitProgramas" ):
                listener.exitProgramas(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitProgramas" ):
                return visitor.visitProgramas(self)
            else:
                return visitor.visitChildren(self)



    def program(self):

        localctx = yaplParser.ProgramContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_program)
        self._la = 0 # Token type
        try:
            localctx = yaplParser.ProgramasContext(self, localctx)
            self.enterOuterAlt(localctx, 1)
            self.state = 13 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 10
                self.classdef()
                self.state = 11
                self.match(yaplParser.T__0)
                self.state = 15 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==21):
                    break

            self.state = 17
            self.match(yaplParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ClassdefContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return yaplParser.RULE_classdef

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class ClaseContext(ClassdefContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a yaplParser.ClassdefContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def CLASS(self):
            return self.getToken(yaplParser.CLASS, 0)
        def TYPE(self, i:int=None):
            if i is None:
                return self.getTokens(yaplParser.TYPE)
            else:
                return self.getToken(yaplParser.TYPE, i)
        def INHERITS(self):
            return self.getToken(yaplParser.INHERITS, 0)
        def feature(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(yaplParser.FeatureContext)
            else:
                return self.getTypedRuleContext(yaplParser.FeatureContext,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterClase" ):
                listener.enterClase(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitClase" ):
                listener.exitClase(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitClase" ):
                return visitor.visitClase(self)
            else:
                return visitor.visitChildren(self)



    def classdef(self):

        localctx = yaplParser.ClassdefContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_classdef)
        self._la = 0 # Token type
        try:
            localctx = yaplParser.ClaseContext(self, localctx)
            self.enterOuterAlt(localctx, 1)
            self.state = 19
            self.match(yaplParser.CLASS)
            self.state = 20
            self.match(yaplParser.TYPE)
            self.state = 23
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==27:
                self.state = 21
                self.match(yaplParser.INHERITS)
                self.state = 22
                self.match(yaplParser.TYPE)


            self.state = 25
            self.match(yaplParser.T__1)
            self.state = 31
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==43:
                self.state = 26
                self.feature()
                self.state = 27
                self.match(yaplParser.T__0)
                self.state = 33
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 34
            self.match(yaplParser.T__2)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FeatureContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return yaplParser.RULE_feature

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class PropiedadContext(FeatureContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a yaplParser.FeatureContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def formal(self):
            return self.getTypedRuleContext(yaplParser.FormalContext,0)

        def ASSIGNMENT(self):
            return self.getToken(yaplParser.ASSIGNMENT, 0)
        def expr(self):
            return self.getTypedRuleContext(yaplParser.ExprContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPropiedad" ):
                listener.enterPropiedad(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPropiedad" ):
                listener.exitPropiedad(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPropiedad" ):
                return visitor.visitPropiedad(self)
            else:
                return visitor.visitChildren(self)


    class MetodoContext(FeatureContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a yaplParser.FeatureContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def ID(self):
            return self.getToken(yaplParser.ID, 0)
        def TYPE(self):
            return self.getToken(yaplParser.TYPE, 0)
        def expr(self):
            return self.getTypedRuleContext(yaplParser.ExprContext,0)

        def formal(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(yaplParser.FormalContext)
            else:
                return self.getTypedRuleContext(yaplParser.FormalContext,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMetodo" ):
                listener.enterMetodo(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMetodo" ):
                listener.exitMetodo(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMetodo" ):
                return visitor.visitMetodo(self)
            else:
                return visitor.visitChildren(self)



    def feature(self):

        localctx = yaplParser.FeatureContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_feature)
        self._la = 0 # Token type
        try:
            self.state = 63
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,6,self._ctx)
            if la_ == 1:
                localctx = yaplParser.MetodoContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 36
                self.match(yaplParser.ID)
                self.state = 37
                self.match(yaplParser.T__3)
                self.state = 48
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==43:
                    self.state = 38
                    self.formal()
                    self.state = 43
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)
                    while _la==5:
                        self.state = 39
                        self.match(yaplParser.T__4)
                        self.state = 40
                        self.formal()
                        self.state = 45
                        self._errHandler.sync(self)
                        _la = self._input.LA(1)

                    self.state = 50
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                self.state = 51
                self.match(yaplParser.T__5)
                self.state = 52
                self.match(yaplParser.T__6)
                self.state = 53
                self.match(yaplParser.TYPE)
                self.state = 54
                self.match(yaplParser.T__1)
                self.state = 55
                self.expr(0)
                self.state = 56
                self.match(yaplParser.T__2)
                pass

            elif la_ == 2:
                localctx = yaplParser.PropiedadContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 58
                self.formal()
                self.state = 61
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==44:
                    self.state = 59
                    self.match(yaplParser.ASSIGNMENT)
                    self.state = 60
                    self.expr(0)


                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FormalContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return yaplParser.RULE_formal

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class AsignacionContext(FormalContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a yaplParser.FormalContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def ID(self):
            return self.getToken(yaplParser.ID, 0)
        def TYPE(self):
            return self.getToken(yaplParser.TYPE, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAsignacion" ):
                listener.enterAsignacion(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAsignacion" ):
                listener.exitAsignacion(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAsignacion" ):
                return visitor.visitAsignacion(self)
            else:
                return visitor.visitChildren(self)



    def formal(self):

        localctx = yaplParser.FormalContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_formal)
        try:
            localctx = yaplParser.AsignacionContext(self, localctx)
            self.enterOuterAlt(localctx, 1)
            self.state = 65
            self.match(yaplParser.ID)
            self.state = 66
            self.match(yaplParser.T__6)
            self.state = 67
            self.match(yaplParser.TYPE)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExprContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return yaplParser.RULE_expr

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)


    class NewContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a yaplParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def NEW(self):
            return self.getToken(yaplParser.NEW, 0)
        def TYPE(self):
            return self.getToken(yaplParser.TYPE, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNew" ):
                listener.enterNew(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNew" ):
                listener.exitNew(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitNew" ):
                return visitor.visitNew(self)
            else:
                return visitor.visitChildren(self)


    class ParenthesesContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a yaplParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expr(self):
            return self.getTypedRuleContext(yaplParser.ExprContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterParentheses" ):
                listener.enterParentheses(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitParentheses" ):
                listener.exitParentheses(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitParentheses" ):
                return visitor.visitParentheses(self)
            else:
                return visitor.visitChildren(self)


    class LetInContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a yaplParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def LET(self):
            return self.getToken(yaplParser.LET, 0)
        def formal(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(yaplParser.FormalContext)
            else:
                return self.getTypedRuleContext(yaplParser.FormalContext,i)

        def IN(self):
            return self.getToken(yaplParser.IN, 0)
        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(yaplParser.ExprContext)
            else:
                return self.getTypedRuleContext(yaplParser.ExprContext,i)

        def ASSIGNMENT(self, i:int=None):
            if i is None:
                return self.getTokens(yaplParser.ASSIGNMENT)
            else:
                return self.getToken(yaplParser.ASSIGNMENT, i)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLetIn" ):
                listener.enterLetIn(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLetIn" ):
                listener.exitLetIn(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLetIn" ):
                return visitor.visitLetIn(self)
            else:
                return visitor.visitChildren(self)


    class StringContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a yaplParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def STRING(self):
            return self.getToken(yaplParser.STRING, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterString" ):
                listener.enterString(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitString" ):
                listener.exitString(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitString" ):
                return visitor.visitString(self)
            else:
                return visitor.visitChildren(self)


    class Arithmetic1Context(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a yaplParser.ExprContext
            super().__init__(parser)
            self.op = None # Token
            self.copyFrom(ctx)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(yaplParser.ExprContext)
            else:
                return self.getTypedRuleContext(yaplParser.ExprContext,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterArithmetic1" ):
                listener.enterArithmetic1(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitArithmetic1" ):
                listener.exitArithmetic1(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitArithmetic1" ):
                return visitor.visitArithmetic1(self)
            else:
                return visitor.visitChildren(self)


    class IsvoidContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a yaplParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def ISVOID(self):
            return self.getToken(yaplParser.ISVOID, 0)
        def expr(self):
            return self.getTypedRuleContext(yaplParser.ExprContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIsvoid" ):
                listener.enterIsvoid(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIsvoid" ):
                listener.exitIsvoid(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIsvoid" ):
                return visitor.visitIsvoid(self)
            else:
                return visitor.visitChildren(self)


    class AssignmentContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a yaplParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def ID(self):
            return self.getToken(yaplParser.ID, 0)
        def ASSIGNMENT(self):
            return self.getToken(yaplParser.ASSIGNMENT, 0)
        def expr(self):
            return self.getTypedRuleContext(yaplParser.ExprContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAssignment" ):
                listener.enterAssignment(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAssignment" ):
                listener.exitAssignment(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAssignment" ):
                return visitor.visitAssignment(self)
            else:
                return visitor.visitChildren(self)


    class Arithmetic2Context(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a yaplParser.ExprContext
            super().__init__(parser)
            self.op = None # Token
            self.copyFrom(ctx)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(yaplParser.ExprContext)
            else:
                return self.getTypedRuleContext(yaplParser.ExprContext,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterArithmetic2" ):
                listener.enterArithmetic2(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitArithmetic2" ):
                listener.exitArithmetic2(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitArithmetic2" ):
                return visitor.visitArithmetic2(self)
            else:
                return visitor.visitChildren(self)


    class WhileContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a yaplParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def WHILE(self):
            return self.getToken(yaplParser.WHILE, 0)
        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(yaplParser.ExprContext)
            else:
                return self.getTypedRuleContext(yaplParser.ExprContext,i)

        def LOOP(self):
            return self.getToken(yaplParser.LOOP, 0)
        def POOL(self):
            return self.getToken(yaplParser.POOL, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterWhile" ):
                listener.enterWhile(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitWhile" ):
                listener.exitWhile(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitWhile" ):
                return visitor.visitWhile(self)
            else:
                return visitor.visitChildren(self)


    class IntContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a yaplParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def INT(self):
            return self.getToken(yaplParser.INT, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterInt" ):
                listener.enterInt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitInt" ):
                listener.exitInt(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitInt" ):
                return visitor.visitInt(self)
            else:
                return visitor.visitChildren(self)


    class DispatchImplicitBContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a yaplParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def ID(self):
            return self.getToken(yaplParser.ID, 0)
        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(yaplParser.ExprContext)
            else:
                return self.getTypedRuleContext(yaplParser.ExprContext,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDispatchImplicitB" ):
                listener.enterDispatchImplicitB(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDispatchImplicitB" ):
                listener.exitDispatchImplicitB(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitDispatchImplicitB" ):
                return visitor.visitDispatchImplicitB(self)
            else:
                return visitor.visitChildren(self)


    class NegativeContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a yaplParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expr(self):
            return self.getTypedRuleContext(yaplParser.ExprContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNegative" ):
                listener.enterNegative(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNegative" ):
                listener.exitNegative(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitNegative" ):
                return visitor.visitNegative(self)
            else:
                return visitor.visitChildren(self)


    class BoolNotContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a yaplParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def NOT(self):
            return self.getToken(yaplParser.NOT, 0)
        def expr(self):
            return self.getTypedRuleContext(yaplParser.ExprContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBoolNot" ):
                listener.enterBoolNot(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBoolNot" ):
                listener.exitBoolNot(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitBoolNot" ):
                return visitor.visitBoolNot(self)
            else:
                return visitor.visitChildren(self)


    class BooleanContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a yaplParser.ExprContext
            super().__init__(parser)
            self.value = None # Token
            self.copyFrom(ctx)

        def TRUE(self):
            return self.getToken(yaplParser.TRUE, 0)
        def FALSE(self):
            return self.getToken(yaplParser.FALSE, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBoolean" ):
                listener.enterBoolean(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBoolean" ):
                listener.exitBoolean(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitBoolean" ):
                return visitor.visitBoolean(self)
            else:
                return visitor.visitChildren(self)


    class BlockContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a yaplParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(yaplParser.ExprContext)
            else:
                return self.getTypedRuleContext(yaplParser.ExprContext,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBlock" ):
                listener.enterBlock(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBlock" ):
                listener.exitBlock(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitBlock" ):
                return visitor.visitBlock(self)
            else:
                return visitor.visitChildren(self)


    class ComparissonContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a yaplParser.ExprContext
            super().__init__(parser)
            self.op = None # Token
            self.copyFrom(ctx)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(yaplParser.ExprContext)
            else:
                return self.getTypedRuleContext(yaplParser.ExprContext,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterComparisson" ):
                listener.enterComparisson(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitComparisson" ):
                listener.exitComparisson(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitComparisson" ):
                return visitor.visitComparisson(self)
            else:
                return visitor.visitChildren(self)


    class IdContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a yaplParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def ID(self):
            return self.getToken(yaplParser.ID, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterId" ):
                listener.enterId(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitId" ):
                listener.exitId(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitId" ):
                return visitor.visitId(self)
            else:
                return visitor.visitChildren(self)


    class IfContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a yaplParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def IF(self):
            return self.getToken(yaplParser.IF, 0)
        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(yaplParser.ExprContext)
            else:
                return self.getTypedRuleContext(yaplParser.ExprContext,i)

        def THEN(self):
            return self.getToken(yaplParser.THEN, 0)
        def ELSE(self):
            return self.getToken(yaplParser.ELSE, 0)
        def FI(self):
            return self.getToken(yaplParser.FI, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIf" ):
                listener.enterIf(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIf" ):
                listener.exitIf(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIf" ):
                return visitor.visitIf(self)
            else:
                return visitor.visitChildren(self)


    class DispatchExplicitAContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a yaplParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(yaplParser.ExprContext)
            else:
                return self.getTypedRuleContext(yaplParser.ExprContext,i)

        def ID(self):
            return self.getToken(yaplParser.ID, 0)
        def TYPE(self):
            return self.getToken(yaplParser.TYPE, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDispatchExplicitA" ):
                listener.enterDispatchExplicitA(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDispatchExplicitA" ):
                listener.exitDispatchExplicitA(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitDispatchExplicitA" ):
                return visitor.visitDispatchExplicitA(self)
            else:
                return visitor.visitChildren(self)



    def expr(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = yaplParser.ExprContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 8
        self.enterRecursionRule(localctx, 8, self.RULE_expr, _p)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 149
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,13,self._ctx)
            if la_ == 1:
                localctx = yaplParser.DispatchImplicitBContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx

                self.state = 70
                self.match(yaplParser.ID)
                self.state = 71
                self.match(yaplParser.T__3)
                self.state = 82
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while (((_la) & ~0x3f) == 0 and ((1 << _la) & 12997418288148) != 0):
                    self.state = 72
                    self.expr(0)
                    self.state = 77
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)
                    while _la==5:
                        self.state = 73
                        self.match(yaplParser.T__4)
                        self.state = 74
                        self.expr(0)
                        self.state = 79
                        self._errHandler.sync(self)
                        _la = self._input.LA(1)

                    self.state = 84
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                self.state = 85
                self.match(yaplParser.T__5)
                pass

            elif la_ == 2:
                localctx = yaplParser.IfContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 86
                self.match(yaplParser.IF)
                self.state = 87
                self.expr(0)
                self.state = 88
                self.match(yaplParser.THEN)
                self.state = 89
                self.expr(0)
                self.state = 90
                self.match(yaplParser.ELSE)
                self.state = 91
                self.expr(0)
                self.state = 92
                self.match(yaplParser.FI)
                pass

            elif la_ == 3:
                localctx = yaplParser.WhileContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 94
                self.match(yaplParser.WHILE)
                self.state = 95
                self.expr(0)
                self.state = 96
                self.match(yaplParser.LOOP)
                self.state = 97
                self.expr(0)
                self.state = 98
                self.match(yaplParser.POOL)
                pass

            elif la_ == 4:
                localctx = yaplParser.BlockContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 100
                self.match(yaplParser.T__1)
                self.state = 104 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while True:
                    self.state = 101
                    self.expr(0)
                    self.state = 102
                    self.match(yaplParser.T__0)
                    self.state = 106 
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)
                    if not ((((_la) & ~0x3f) == 0 and ((1 << _la) & 12997418288148) != 0)):
                        break

                self.state = 108
                self.match(yaplParser.T__2)
                pass

            elif la_ == 5:
                localctx = yaplParser.NewContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 110
                self.match(yaplParser.NEW)
                self.state = 111
                self.match(yaplParser.TYPE)
                pass

            elif la_ == 6:
                localctx = yaplParser.NegativeContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 112
                self.match(yaplParser.T__9)
                self.state = 113
                self.expr(13)
                pass

            elif la_ == 7:
                localctx = yaplParser.IsvoidContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 114
                self.match(yaplParser.ISVOID)
                self.state = 115
                self.expr(12)
                pass

            elif la_ == 8:
                localctx = yaplParser.BoolNotContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 116
                self.match(yaplParser.NOT)
                self.state = 117
                self.expr(8)
                pass

            elif la_ == 9:
                localctx = yaplParser.ParenthesesContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 118
                self.match(yaplParser.T__3)
                self.state = 119
                self.expr(0)
                self.state = 120
                self.match(yaplParser.T__5)
                pass

            elif la_ == 10:
                localctx = yaplParser.IdContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 122
                self.match(yaplParser.ID)
                pass

            elif la_ == 11:
                localctx = yaplParser.IntContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 123
                self.match(yaplParser.INT)
                pass

            elif la_ == 12:
                localctx = yaplParser.StringContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 124
                self.match(yaplParser.STRING)
                pass

            elif la_ == 13:
                localctx = yaplParser.BooleanContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 125
                localctx.value = self._input.LT(1)
                _la = self._input.LA(1)
                if not(_la==23 or _la==39):
                    localctx.value = self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                pass

            elif la_ == 14:
                localctx = yaplParser.AssignmentContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 126
                self.match(yaplParser.ID)
                self.state = 127
                self.match(yaplParser.ASSIGNMENT)
                self.state = 128
                self.expr(2)
                pass

            elif la_ == 15:
                localctx = yaplParser.LetInContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 129
                self.match(yaplParser.LET)
                self.state = 130
                self.formal()
                self.state = 133
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==44:
                    self.state = 131
                    self.match(yaplParser.ASSIGNMENT)
                    self.state = 132
                    self.expr(0)


                self.state = 143
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==5:
                    self.state = 135
                    self.match(yaplParser.T__4)
                    self.state = 136
                    self.formal()
                    self.state = 139
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)
                    if _la==44:
                        self.state = 137
                        self.match(yaplParser.ASSIGNMENT)
                        self.state = 138
                        self.expr(0)


                    self.state = 145
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                self.state = 146
                self.match(yaplParser.IN)
                self.state = 147
                self.expr(1)
                pass


            self._ctx.stop = self._input.LT(-1)
            self.state = 184
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,18,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    self.state = 182
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,17,self._ctx)
                    if la_ == 1:
                        localctx = yaplParser.Arithmetic1Context(self, yaplParser.ExprContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 151
                        if not self.precpred(self._ctx, 11):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 11)")
                        self.state = 152
                        localctx.op = self._input.LT(1)
                        _la = self._input.LA(1)
                        if not(_la==11 or _la==12):
                            localctx.op = self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 153
                        self.expr(12)
                        pass

                    elif la_ == 2:
                        localctx = yaplParser.Arithmetic2Context(self, yaplParser.ExprContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 154
                        if not self.precpred(self._ctx, 10):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 10)")
                        self.state = 155
                        localctx.op = self._input.LT(1)
                        _la = self._input.LA(1)
                        if not(_la==13 or _la==14):
                            localctx.op = self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 156
                        self.expr(11)
                        pass

                    elif la_ == 3:
                        localctx = yaplParser.ComparissonContext(self, yaplParser.ExprContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 157
                        if not self.precpred(self._ctx, 9):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 9)")
                        self.state = 158
                        localctx.op = self._input.LT(1)
                        _la = self._input.LA(1)
                        if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 229376) != 0)):
                            localctx.op = self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 159
                        self.expr(10)
                        pass

                    elif la_ == 4:
                        localctx = yaplParser.DispatchExplicitAContext(self, yaplParser.ExprContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 160
                        if not self.precpred(self._ctx, 19):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 19)")
                        self.state = 163
                        self._errHandler.sync(self)
                        _la = self._input.LA(1)
                        if _la==8:
                            self.state = 161
                            self.match(yaplParser.T__7)
                            self.state = 162
                            self.match(yaplParser.TYPE)


                        self.state = 165
                        self.match(yaplParser.T__8)
                        self.state = 166
                        self.match(yaplParser.ID)
                        self.state = 167
                        self.match(yaplParser.T__3)
                        self.state = 178
                        self._errHandler.sync(self)
                        _la = self._input.LA(1)
                        while (((_la) & ~0x3f) == 0 and ((1 << _la) & 12997418288148) != 0):
                            self.state = 168
                            self.expr(0)
                            self.state = 173
                            self._errHandler.sync(self)
                            _la = self._input.LA(1)
                            while _la==5:
                                self.state = 169
                                self.match(yaplParser.T__4)
                                self.state = 170
                                self.expr(0)
                                self.state = 175
                                self._errHandler.sync(self)
                                _la = self._input.LA(1)

                            self.state = 180
                            self._errHandler.sync(self)
                            _la = self._input.LA(1)

                        self.state = 181
                        self.match(yaplParser.T__5)
                        pass

             
                self.state = 186
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,18,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx



    def sempred(self, localctx:RuleContext, ruleIndex:int, predIndex:int):
        if self._predicates == None:
            self._predicates = dict()
        self._predicates[4] = self.expr_sempred
        pred = self._predicates.get(ruleIndex, None)
        if pred is None:
            raise Exception("No predicate with index:" + str(ruleIndex))
        else:
            return pred(localctx, predIndex)

    def expr_sempred(self, localctx:ExprContext, predIndex:int):
            if predIndex == 0:
                return self.precpred(self._ctx, 11)
         

            if predIndex == 1:
                return self.precpred(self._ctx, 10)
         

            if predIndex == 2:
                return self.precpred(self._ctx, 9)
         

            if predIndex == 3:
                return self.precpred(self._ctx, 19)
         




